const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
app.use(cors());
app.use(express.json());


app.use(
  '/api/auth',
  createProxyMiddleware({
    target: process.env.AUTH_SERVICE_URL,
    changeOrigin: true,
  })
);


app.use(
  '/api/courses',
  createProxyMiddleware({
    target: process.env.COURSE_SERVICE_URL,
    changeOrigin: true,
  })
);


app.get('/', (req, res) => {
  res.send('API Gateway is running');
});

module.exports = app;