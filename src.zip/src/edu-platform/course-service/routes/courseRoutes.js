const express = require('express');
const router = express.Router();

const courses = require('../data/courses');
const { authenticateToken } = require('../middlewares/authMiddleware');
const { authorizeRoles } = require('../middlewares/roleMiddleware');


// 📌 همه کاربران لاگین کرده → لیست درس‌ها
router.get('/', authenticateToken, (req, res) => {
  res.json({
    user: req.user.name,
    role: req.user.role,
    courses
  });
});


// 👨‍🏫 فقط استاد و ادمین → لیست دانشجوهای یک درس
router.get(
  '/:id/students',
  authenticateToken,
  authorizeRoles('teacher', 'admin'),
  (req, res) => {
    const course = courses.find(c => c.id === req.params.id);
    if (!course) return res.status(404).json({ message: 'درس پیدا نشد' });

    res.json({
      course: course.name,
      students: course.students
    });
  }
);


// 🧑‍🎓 فقط دانشجو → دیدن درس‌های خودش
router.get(
  '/my-courses',
  authenticateToken,
  authorizeRoles('student'),
  (req, res) => {
    const myCourses = courses.filter(c =>
      c.students.includes(req.user.userId)
    );

    res.json({
      student: req.user.name,
      courses: myCourses
    });
  }
);

module.exports = router;
