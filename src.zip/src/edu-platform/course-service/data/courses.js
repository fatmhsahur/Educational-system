const courses = [
  {
    id: '1',
    name: 'مهندسی نرم‌افزار',
    teacher: 'دکتر اسلامی',
    students: ['40012113', '40012114']
  },
  {
    id: '2',
    name: 'هوش مصنوعی',
    teacher: 'دکتر محمدی',
    students: ['40012115', '40012116']
  }
];

module.exports = courses;
