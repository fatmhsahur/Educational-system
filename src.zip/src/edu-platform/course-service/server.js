require('dotenv').config();
const app = require('./app');
console.log('bruh')
const PORT = process.env.PORT || 5001;

app.listen(PORT, () => {
  console.log(`📚 Course Service running on port ${PORT}`);
});