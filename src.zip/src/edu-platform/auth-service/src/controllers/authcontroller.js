const { loginUser } = require('../services/authService');

const login = async (req, res) => {
  try {
    const { id, role } = req.body;

    if (!id || !role) {
      return res.status(400).json({ message: 'id and role are required' });
    }

    const result = await loginUser(id, role);

    res.json(result);
  } catch (err) {
    res.status(401).json({ message: 'شناسه یا نقش اشتباه است' });
  }
};

module.exports = { login };
