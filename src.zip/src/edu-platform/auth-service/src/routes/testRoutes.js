const express = require('express');
const router = express.Router();

const { authenticateToken } = require('../middlewares/authMiddleware');

router.get('/me', authenticateToken, (req, res) => {
  res.json({
    message: 'توکن معتبر است ✅',
    user: req.user
  });
});

module.exports = router;
