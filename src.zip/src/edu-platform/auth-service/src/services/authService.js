const jwt = require('jsonwebtoken');
const users = require('../data/users');

const loginUser = async (id, role) => {
  const user = users.find(u => u.id === id && u.role === role);

  if (!user) {
    throw new Error('Invalid credentials');
  }

  const token = jwt.sign(
    {
      userId: user.id,
      role: user.role,
      name: user.name,
    },
    process.env.JWT_SECRET,
    { expiresIn: '1d' }
  );

  return {
    token,
    user: {
      id: user.id,
      name: user.name,
      role: user.role,
    },
  };
};

module.exports = { loginUser };