const bcrypt = require('bcryptjs');

// در پروژه واقعی اینا داخل دیتابیس هستن 
const users = [
  // Students
  { id: '40012113', name: 'امیرحسین پارسی', role: 'student' },
  { id: '40012114', name: 'محمدصادق بیدختی', role: 'student' },
  { id: '40012115', name: 'علی رضایی', role: 'student' },
  { id: '40012116', name: 'فاطمه ساهور', role: 'student' },

  // Teachers
  { id: '9001', name: 'دکتر اسلامی', role: 'teacher' },
  { id: '9002', name: 'دکتر کریمی', role: 'teacher' },
  { id: '9003', name: 'دکتر محمدی', role: 'teacher' },

  // Admins
  { id: 'admin123', name: 'مدیر سیستم', role: 'admin' },
  { id: 'admin456', name: 'مدیر ارشد', role: 'admin' },
];

module.exports = users;
